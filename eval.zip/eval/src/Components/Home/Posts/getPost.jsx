// const handleScroll = event => {
//     const {scrollTop, clientHeight, scrollHeight} = event.currentTarget;

//     if(scrollHeight - scrollTop == clientHeight){
//       setPage(prev => prev +1)
//     }
//   }


//   useEffect(() => {
//     // const loadUsers = async () => {
//     //   setLoading(true);
//     //   const newPost = await getPosts(setAllPosts, page)
//     //   console.log(newPost)
//     //   // setAllPosts((prev) => [...prev, ...newPost]);
//     //   setLoading(false)
//     // }
//     // loadUsers()
//     // getPosts(setAllPosts, page)
    
//   }, [page]);