import React from 'react'

function Registration() {
    return (
        <div>
            <div>Registration</div>
        </div>
    )
}

export default Registration
