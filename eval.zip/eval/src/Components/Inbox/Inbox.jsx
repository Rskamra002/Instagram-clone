import React from 'react'

const Inbox = () => {
    return (
        <div>
            
        </div>
    )
}

export {Inbox}
