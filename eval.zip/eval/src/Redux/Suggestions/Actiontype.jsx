export const GET_USER_REQ = "GET_USER_REQ"
export const GET_USER_SUC = "GET_USER_SUC"
export const GET_USER_FAIL = "GET_USER_FAIL"
