export const LOGIN_REQ = "LOGIN_REQ"
export const LOGIN_SUC = "LOGIN_SUC"
export const LOGIN_FAIL = "LOGIN_FAIL"

export const LOGOUT_SUC = "LOGOUT_SUC"
